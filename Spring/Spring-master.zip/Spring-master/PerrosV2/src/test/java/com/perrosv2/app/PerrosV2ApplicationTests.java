package com.perrosv2.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerrosV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
