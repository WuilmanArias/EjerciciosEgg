package com.perrosv2.app.enums;

public enum Rol {
	USUARIO, ADMIN;
}
