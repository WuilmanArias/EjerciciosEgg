package com.perrosv2.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerrosV2Application {

	public static void main(String[] args) {
		SpringApplication.run(PerrosV2Application.class, args);
	}

}
