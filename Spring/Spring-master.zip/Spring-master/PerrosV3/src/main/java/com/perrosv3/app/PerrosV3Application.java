package com.perrosv3.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerrosV3Application {

	public static void main(String[] args) {
		SpringApplication.run(PerrosV3Application.class, args);
	}

}
