package com.perrosv3.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerrosV3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
