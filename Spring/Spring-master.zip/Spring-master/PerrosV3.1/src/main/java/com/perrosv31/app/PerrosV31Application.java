package com.perrosv31.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerrosV31Application {

	public static void main(String[] args) {
		SpringApplication.run(PerrosV31Application.class, args);
	}

}
