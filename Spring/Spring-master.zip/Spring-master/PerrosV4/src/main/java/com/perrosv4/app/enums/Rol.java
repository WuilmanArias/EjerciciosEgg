package com.perrosv4.app.enums;

public enum Rol { SUPERADMIN, ADMIN, USUARIO }
