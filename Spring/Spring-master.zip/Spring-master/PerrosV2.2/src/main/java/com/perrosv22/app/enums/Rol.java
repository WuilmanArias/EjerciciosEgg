package com.perrosv22.app.enums;

public enum Rol { SUPERADMIN, ADMIN}
