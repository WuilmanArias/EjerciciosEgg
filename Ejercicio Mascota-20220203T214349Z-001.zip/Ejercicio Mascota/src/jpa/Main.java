package jpa;

import jpa.servicios.UsuarioServicio;

public class Main {

    public static void main(String[] args) {

        UsuarioServicio usuarioServicio = new UsuarioServicio();

        try {
            
           
            
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

    }

}
